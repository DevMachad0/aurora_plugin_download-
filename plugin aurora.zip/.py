import requests

url = "https://api.rd.services/oauth2/token"

payload = {
    "client_id": "0ae09d6b-9d04-40ae-b1bf-acf56b4c47e5",
    "client_secret": "4a27cc686c7049039791d53caf4285aa",
    "code": "7SfLNpmLmfLjlCW8xelOPDQAOChgS84p",
    "redirect_uri": "https://www.simplusbr.com/",
    "grant_type": "authorization_code"
}

headers = {
    "Content-Type": "application/x-www-form-urlencoded"
}

response = requests.post(url, data=payload, headers=headers)

if response.status_code == 200:
    print("Token gerado com sucesso!")
    print(response.json())
else:
    print("Erro ao gerar token")
    print("Status:", response.status_code)
    print("Resposta:", response.text)
