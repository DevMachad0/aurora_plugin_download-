<?php
/**
 * Template: Vitrificado (Glassmorphism)
 * Tipo: Bubble (Balão de Diálogo)
 * Usa o mesmo layout base, apenas aplica tema vitrificado via CSS
 */
?>

<div class="aurora-bubble aurora-bubble--vitrificado" data-aurora-role="bubble" data-aurora-template="vitrificado"
    aria-live="polite">
    <button class="aurora-bubble__launcher" type="button" aria-controls="aurora-bubble-panel" aria-expanded="false">
        <span class="aurora-bubble__launcher-icon" aria-hidden="true">
            <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none"
                stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                class="aurora-icon-message">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
            </svg>
        </span>
        <span class="aurora-bubble__launcher-label" data-aurora-role="launcher-label"></span>
    </button>

    <div class="aurora-bubble__overlay" data-aurora-role="overlay" hidden></div>

    <div class="aurora-bubble__panel" id="aurora-bubble-panel" hidden aria-modal="true" role="dialog"
        aria-label="Chat Aurora">
        <header class="aurora-bubble__header">
            <div class="aurora-bubble__brand">
                <span class="aurora-bubble__brand-icon" aria-hidden="true">A◦</span>
                <div class="aurora-bubble__brand-copy">
                    <span class="aurora-bubble__brand-name">Aurora Chat</span>
                    <span class="aurora-bubble__brand-status" data-aurora-role="status">Online</span>
                </div>
            </div>
            <button type="button" class="aurora-theme-toggle-btn" data-aurora-role="theme-toggle"
                aria-label="Alternar tema" title="Alternar tema">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none"
                    stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                    class="aurora-icon-theme">
                    <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
                </svg>
            </button>
        </header>

        <section class="aurora-bubble__welcome" data-aurora-role="welcome">
            <h2 class="aurora-bubble__welcome-title">Bem-vindo</h2>
            <p class="aurora-bubble__welcome-subtitle">Estamos aqui para ajudar!</p>
            <button class="aurora-bubble__start" type="button" data-aurora-role="start">Envie-nos uma mensagem</button>
        </section>

        <div class="aurora-bubble__thread" data-aurora-role="messages" tabindex="0">
            <article class="aurora-bubble__message is-bot">
                <div class="aurora-bubble__bubble">
                    <p>Olá! Sou o Aurora, seu copiloto digital. Como posso te ajudar hoje?</p>
                </div>
            </article>
        </div>

        <form class="aurora-bubble__composer" data-aurora-role="composer" hidden>
            <label class="screen-reader-text" for="aurora-bubble-input">Mensagem</label>
            <div class="aurora-input-group">
                <input id="aurora-bubble-input" class="aurora-bubble__input" type="text" autocomplete="off"
                    placeholder="Digite sua mensagem" required />
                <div class="aurora-actions">
                    <button type="button" class="aurora-bubble__mic" data-aurora-role="mic"
                        aria-label="Gravar mensagem de voz" title="Gravar mensagem de voz">
                        <span aria-hidden="true">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24"
                                fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" class="aurora-icon-mic">
                                <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path>
                                <path d="M19 10v2a7 7 0 0 1-14 0v-2"></path>
                                <line x1="12" y1="19" x2="12" y2="23"></line>
                                <line x1="8" y1="23" x2="16" y2="23"></line>
                            </svg>
                        </span>
                    </button>
                    <button type="submit" class="aurora-bubble__send" data-aurora-role="send"
                        aria-label="Enviar mensagem">
                        <span aria-hidden="true">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24"
                                fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" class="aurora-icon-send">
                                <line x1="22" y1="2" x2="11" y2="13"></line>
                                <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                            </svg>
                        </span>
                    </button>
                </div>
            </div>
        </form>

        <div class="aurora-bubble__limit" data-aurora-role="char-limit" aria-live="polite" hidden></div>

        <div class="aurora-bubble__footer" data-aurora-role="footer"><small>Feito por Aurora Tecnologia e
                Inovação</small></div>
        <div class="aurora-toast-container" data-aurora-role="toast-container"></div>
    </div>
</div>